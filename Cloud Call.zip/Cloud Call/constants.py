# constants.py
# Shared constants for the Cloud Call app

CATEGORIES = ["flood", "rain", "cyclone", "tsunami", "wind", "fire", "landslide", "power", "other"]

SEVERITIES = ["Low", "Medium", "High", "Critical"]

STATUSES = ["New", "In Review", "Assigned", "Resolved", "Rejected"]

DAMAGE_TYPES = ["Flooding", "Road blocked", "Tree/branch down", "Fire", "Power outage", "Injury/medical", "Property damage", "Other"]

PROVINCE_TO_DISTRICTS = {
    "Western": ["Colombo", "Gampaha", "Kalutara"],
    "Central": ["Kandy", "Matale", "Nuwara Eliya"],
    "Southern": ["Galle", "Matara", "Hambantota"],
    "Northern": ["Jaffna", "Kilinochchi", "Mannar", "Mullaitivu", "Vavuniya"],
    "Eastern": ["Trincomalee", "Batticaloa", "Ampara"],
    "North Western": ["Kurunegala", "Puttalam"],
    "North Central": ["Anuradhapura", "Polonnaruwa"],
    "Uva": ["Badulla", "Monaragala"],
    "Sabaragamuwa": ["Ratnapura", "Kegalle"],
}

# Approx centroids for Sri Lanka districts (rough, good enough for pins/heatmaps)
DISTRICT_CENTROIDS = {
    "Colombo": (6.9271, 79.8612),
    "Gampaha": (7.0840, 79.9930),
    "Kalutara": (6.5854, 79.9607),
    "Kandy": (7.2906, 80.6337),
    "Matale": (7.4675, 80.6234),
    "Nuwara Eliya": (6.9708, 80.7829),
    "Galle": (6.0535, 80.2210),
    "Matara": (5.9485, 80.5353),
    "Hambantota": (6.1241, 81.1185),
    "Jaffna": (9.6615, 80.0255),
    "Kilinochchi": (9.3803, 80.3770),
    "Mannar": (8.9810, 79.9044),
    "Mullaitivu": (9.2671, 80.8121),
    "Vavuniya": (8.7514, 80.4971),
    "Trincomalee": (8.5874, 81.2152),
    "Batticaloa": (7.7170, 81.7000),
    "Ampara": (7.2975, 81.6750),
    "Kurunegala": (7.4863, 80.3623),
    "Puttalam": (8.0400, 79.8300),
    "Anuradhapura": (8.3114, 80.4037),
    "Polonnaruwa": (7.9403, 81.0188),
    "Badulla": (6.9934, 81.0550),
    "Monaragala": (6.8720, 81.3490),
    "Ratnapura": (6.7056, 80.3847),
    "Kegalle": (7.2513, 80.3464),
}
