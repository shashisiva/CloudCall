import streamlit as st

dashboard = st.Page("pages/Dashboard.py", title="Dashboard", default=True, icon="📊")
issues    = st.Page("pages/Issues.py", title="Report A Disaster Issue", icon="📝")
mapview   = st.Page("pages/Map.py", title="Map View", icon="🗺️")
analytics = st.Page("pages/Analytics.py", title="Analytics", icon="📈")
alerts    = st.Page("pages/Alert.py", title="Alerts & Subscriptions", icon="🔔")
admin     = st.Page("pages/Admin.py", title="Admin / Moderation", icon="🛡️")
about     = st.Page("pages/About.py", title="About This Application", icon="ℹ️")

pg = st.navigation([dashboard, issues, mapview, analytics, alerts, admin, about])
pg.run()
