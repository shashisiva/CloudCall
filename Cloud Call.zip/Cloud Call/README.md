# Cloud Call (Enhanced)

A Streamlit multi-page demo app for disaster issue reporting + dashboards + map + analytics + alerts + admin moderation.

## Run

```bash
pip install -r requirements.txt
streamlit run sampleApp.py
```

## Optional: enable real email alerts

Set environment variables:

- SMTP_HOST (e.g. smtp.gmail.com)
- SMTP_PORT (e.g. 587)
- SMTP_USER
- SMTP_PASS
- FROM_EMAIL

If SMTP is not configured, the app will simulate sending and show the email content instead.
