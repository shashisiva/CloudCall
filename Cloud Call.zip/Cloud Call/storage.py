# storage.py
import json
import os
from datetime import datetime
from uuid import uuid4
from typing import Any, Dict, List, Optional

DATA_DIR = "data"
JSON_PATH = os.path.join(DATA_DIR, "issues.json")
SUBS_PATH = os.path.join(DATA_DIR, "subscriptions.json")
IMAGES_DIR = os.path.join(DATA_DIR, "images")


def ensure_storage():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(IMAGES_DIR, exist_ok=True)
    if not os.path.exists(JSON_PATH):
        with open(JSON_PATH, "w", encoding="utf-8") as f:
            json.dump([], f)
    if not os.path.exists(SUBS_PATH):
        with open(SUBS_PATH, "w", encoding="utf-8") as f:
            json.dump([], f)


def load_json(path: str) -> list:
    ensure_storage()
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        return []


def save_json(path: str, data: list):
    ensure_storage()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# --------------------
# Issues
# --------------------
def load_issues() -> List[Dict[str, Any]]:
    return load_json(JSON_PATH)


def save_issues(all_issues: List[Dict[str, Any]]):
    save_json(JSON_PATH, all_issues)


def add_issue(issue_dict: Dict[str, Any]):
    all_issues = load_issues()
    all_issues.append(issue_dict)
    save_issues(all_issues)


def update_issue(issue_id: str, patch: Dict[str, Any]) -> bool:
    """Patch an existing issue by id. Returns True if updated."""
    all_issues = load_issues()
    updated = False
    for it in all_issues:
        if str(it.get("id")) == str(issue_id):
            it.update(patch)
            updated = True
            break
    if updated:
        save_issues(all_issues)
    return updated


def delete_issue(issue_id: str) -> bool:
    all_issues = load_issues()
    before = len(all_issues)
    all_issues = [x for x in all_issues if str(x.get("id")) != str(issue_id)]
    if len(all_issues) != before:
        save_issues(all_issues)
        return True
    return False


# --------------------
# Subscriptions (alerts)
# --------------------
def load_subscriptions() -> List[Dict[str, Any]]:
    return load_json(SUBS_PATH)


def save_subscriptions(all_subs: List[Dict[str, Any]]):
    save_json(SUBS_PATH, all_subs)


def add_subscription(sub_dict: Dict[str, Any]):
    all_subs = load_subscriptions()
    all_subs.append(sub_dict)
    save_subscriptions(all_subs)


def delete_subscription(sub_id: str) -> bool:
    all_subs = load_subscriptions()
    before = len(all_subs)
    all_subs = [x for x in all_subs if str(x.get("id")) != str(sub_id)]
    if len(all_subs) != before:
        save_subscriptions(all_subs)
        return True
    return False


# --------------------
# Image helpers
# --------------------
def save_uploaded_image(uploaded_file) -> Optional[str]:
    """
    Saves one image to data/images and returns the saved path.
    """
    if uploaded_file is None:
        return None

    ensure_storage()

    name = getattr(uploaded_file, "name", "") or "upload.jpg"
    ext = os.path.splitext(name)[1].lower()
    if ext not in [".jpg", ".jpeg", ".png", ".webp"]:
        ext = ".jpg"

    unique_name = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid4().hex}{ext}"
    image_path = os.path.join(IMAGES_DIR, unique_name)

    img_bytes = uploaded_file.getvalue()
    with open(image_path, "wb") as f:
        f.write(img_bytes)

    return image_path


def save_uploaded_images(files) -> List[str]:
    """
    Saves multiple images to data/images and returns paths.
    """
    paths = []
    if not files:
        return paths
    for f in files:
        p = save_uploaded_image(f)
        if p:
            paths.append(p)
    return paths
