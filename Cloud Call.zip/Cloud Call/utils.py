# utils.py
import datetime as dt
from difflib import SequenceMatcher
from typing import Dict, List, Optional, Tuple

from constants import DISTRICT_CENTROIDS


def parse_ts(issue: dict) -> dt.datetime:
    for k in ("created_at", "incident_datetime"):
        v = issue.get(k)
        if not v:
            continue
        try:
            return dt.datetime.fromisoformat(str(v))
        except Exception:
            pass
    return dt.datetime(1970, 1, 1)


def time_ago(ts: dt.datetime) -> str:
    now = dt.datetime.now(ts.tzinfo) if ts.tzinfo else dt.datetime.now()
    delta = now - ts
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return f"{seconds}s ago"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    return f"{days}d ago"


def get_lat_lon(province: str, district: str, lat: Optional[float], lon: Optional[float]) -> Tuple[float, float]:
    if lat is not None and lon is not None:
        return float(lat), float(lon)
    if district in DISTRICT_CENTROIDS:
        return DISTRICT_CENTROIDS[district]
    # fallback: center of Sri Lanka
    return 7.8731, 80.7718


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, (a or "").lower().strip(), (b or "").lower().strip()).ratio()


def find_possible_duplicate(new_issue: dict, existing: List[dict], minutes_window: int = 60, threshold: float = 0.82) -> Optional[dict]:
    """
    Very simple duplicate detection:
    - same district + category
    - created within last `minutes_window`
    - similar description above threshold
    """
    now = dt.datetime.now()
    new_cat = (new_issue.get("category") or "").lower()
    new_dist = (new_issue.get("district") or "").lower()
    new_desc = (new_issue.get("description") or "")

    for it in existing:
        cat = (it.get("category") or "").lower()
        dist = (it.get("district") or "").lower()
        if cat != new_cat or dist != new_dist:
            continue

        ts = parse_ts(it)
        if ts.year < 2000:
            continue
        if abs((now - ts).total_seconds()) > minutes_window * 60:
            continue

        sim = similarity(new_desc, it.get("description") or "")
        if sim >= threshold:
            return it
    return None
