# notifier.py
import os
import smtplib
from email.message import EmailMessage
from typing import List, Optional

# Optional SMTP settings via environment variables:
# SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, FROM_EMAIL
def send_email(to_emails: List[str], subject: str, body: str) -> bool:
    host = os.getenv("SMTP_HOST", "").strip()
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "").strip()
    pwd  = os.getenv("SMTP_PASS", "").strip()
    from_email = os.getenv("FROM_EMAIL", user).strip()

    # If not configured, we treat as "simulation"
    if not host or not from_email:
        return False

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = ", ".join([x.strip() for x in to_emails if x and x.strip()])
    msg.set_content(body)

    with smtplib.SMTP(host, port, timeout=20) as s:
        s.starttls()
        if user and pwd:
            s.login(user, pwd)
        s.send_message(msg)
    return True
