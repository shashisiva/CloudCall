# ui.py
import streamlit as st
from pathlib import Path

def safe_image(path: str, **kwargs):
    if path and Path(path).exists():
        st.image(path, **kwargs)

def inject_css():
    css = """
    <style>
    .stApp { background: linear-gradient(180deg, #DFF1FF 0%, #F6FBFF 45%, #EAF5FF 100%); }
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header[data-testid="stHeader"] { background: transparent !important; box-shadow: none !important; }
    div[data-testid="stDecoration"] { visibility: hidden; height: 0px; }
    section[data-testid="stSidebar"] {
      background: linear-gradient(180deg, #CFEAFF 0%, #EAF6FF 55%, #CFEAFF 100%);
      border-right: 1px solid rgba(15, 60, 120, 0.15);
    }
    .cc-card {
      background: rgba(255, 255, 255, 0.94);
      border: 1px solid rgba(15, 60, 120, 0.14);
      border-radius: 18px;
      padding: 14px 14px;
      box-shadow: 0 12px 28px rgba(0,0,0,0.07);
      margin-bottom: 14px;
    }
    .cc-title {
      font-weight: 800;
      font-size: 1.05rem;
      color: #0B1F36;
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding-bottom: 8px;
      margin-bottom: 10px;
      border-bottom: 1px solid rgba(15,60,120,0.10);
    }
    .cc-sub { color: rgba(11,31,54,0.70); font-size: 0.92rem; margin-top: -6px; }
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

def card(title: str, right_text: str = ""):
    st.markdown(
        f"""
        <div class="cc-card">
          <div class="cc-title">
            <div>{title}</div>
            <div style="font-weight:700;color:rgba(11,31,54,0.65);font-size:0.9rem;">{right_text}</div>
          </div>
        """,
        unsafe_allow_html=True,
    )

def card_end():
    st.markdown("</div>", unsafe_allow_html=True)
