import streamlit as st
import pandas as pd
import datetime as dt
from pathlib import Path

from storage import load_issues, update_issue, delete_issue
from constants import STATUSES, SEVERITIES
from utils import parse_ts
from ui import inject_css, safe_image, card, card_end

st.set_page_config(page_title="Cloud Call • Admin", layout="wide")
inject_css()

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Admin / Moderation")
    st.caption("Review + clean data")

st.markdown("## 🛡️ Admin / Moderation")
st.markdown('<div class="cc-sub">Approve/reject, delete spam, and quickly manage the queue.</div>', unsafe_allow_html=True)

issues = load_issues() or []
if not issues:
    st.info("No issues yet.")
    st.stop()

# Focus queue: New + In Review
queue = sorted(issues, key=parse_ts, reverse=True)

card("Queue", f"Total: {len(queue)}")
df = pd.DataFrame(queue)
cols = [c for c in ["id","category","severity","status","province","district","created_at","toxicity_score","toxicity_decision"] if c in df.columns]
st.dataframe(df[cols], use_container_width=True, hide_index=True)
card_end()

st.markdown("### Moderate one issue")
ids = [str(x.get("id")) for x in queue if x.get("id")]
selected_id = st.selectbox("Select Issue ID", ids)
it = next((x for x in queue if str(x.get("id")) == str(selected_id)), None)
if not it:
    st.stop()

left, right = st.columns([1.05, 0.95], gap="large")
with left:
    st.markdown("#### Details")
    st.write("**Category:**", it.get("category"))
    st.write("**Province/District:**", it.get("province"), "/", it.get("district"))
    st.write("**Created:**", it.get("created_at"))
    st.write("**Incident:**", it.get("incident_datetime"))
    st.write("**Severity:**", it.get("severity"))
    st.write("**Status:**", it.get("status"))
    st.write("**Toxicity:**", it.get("toxicity_score"), "•", it.get("toxicity_decision"))

    st.write("**Description:**")
    st.write(it.get("description",""))

    images = it.get("images") or []
    if images:
        existing = [p for p in images if p and Path(p).exists()]
        if existing:
            st.image(existing, use_container_width=True)

with right:
    card("Actions", "")
    new_status = st.selectbox("Set status", STATUSES, index=max(0, STATUSES.index(it.get("status","New")) if it.get("status") in STATUSES else 0))
    new_sev = st.selectbox("Set severity", SEVERITIES, index=max(0, SEVERITIES.index(it.get("severity","Medium")) if it.get("severity") in SEVERITIES else 1))
    admin_note = st.text_area("Admin note", value="", height=120)

    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button("Approve", type="primary"):
            patch = {"status": "In Review", "severity": new_sev}
            hist = it.get("history") or []
            hist.append({"ts": dt.datetime.now().isoformat(timespec="seconds"), "action": "approved", "by": "admin", "note": admin_note})
            patch["history"] = hist
            update_issue(str(it.get("id")), patch)
            st.success("Approved ✅ (refresh page)")
    with c2:
        if st.button("Reject"):
            patch = {"status": "Rejected", "severity": new_sev}
            hist = it.get("history") or []
            hist.append({"ts": dt.datetime.now().isoformat(timespec="seconds"), "action": "rejected", "by": "admin", "note": admin_note})
            patch["history"] = hist
            update_issue(str(it.get("id")), patch)
            st.warning("Rejected ✅ (refresh page)")
    with c3:
        if st.button("Save"):
            patch = {"status": new_status, "severity": new_sev}
            hist = it.get("history") or []
            hist.append({"ts": dt.datetime.now().isoformat(timespec="seconds"), "action": "updated", "by": "admin", "note": admin_note})
            patch["history"] = hist
            update_issue(str(it.get("id")), patch)
            st.success("Saved ✅ (refresh page)")

    st.divider()
    st.markdown("#### Dangerous action")
    if st.button("🗑️ Delete issue permanently"):
        ok = delete_issue(str(it.get("id")))
        if ok:
            st.success("Deleted ✅ (refresh page)")
        else:
            st.error("Delete failed.")
    card_end()
