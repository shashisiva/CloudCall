import streamlit as st
import pandas as pd
import datetime as dt

from storage import load_issues
from utils import parse_ts
from ui import inject_css, safe_image, card, card_end

st.set_page_config(page_title="Cloud Call • Analytics", layout="wide")
inject_css()

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Analytics")
    st.caption("Trends + hotspots")

st.markdown("## 📈 Analytics")
st.markdown('<div class="cc-sub">Counts by district/category/status + trends over time.</div>', unsafe_allow_html=True)

issues = load_issues() or []
if not issues:
    st.info("No issues saved yet. Submit one from the Report page.")
    st.stop()

df = pd.DataFrame(issues)
df["ts"] = df.apply(lambda r: parse_ts(r.to_dict()), axis=1)
df["date"] = df["ts"].dt.date

# date filter
today = dt.date.today()
start, end = st.columns(2)
with start:
    d1 = st.date_input("From", value=today - dt.timedelta(days=30))
with end:
    d2 = st.date_input("To", value=today)

df = df[(df["date"] >= d1) & (df["date"] <= d2)]

k1, k2, k3 = st.columns(3)
k1.metric("Total", len(df))
k2.metric("Open (New/In Review/Assigned)", int((df["status"].isin(["New","In Review","Assigned"])).sum()) if "status" in df.columns else 0)
k3.metric("Resolved", int((df["status"] == "Resolved").sum()) if "status" in df.columns else 0)

st.markdown("")

# Trend over time
card("Trend over time", "")
trend = df.groupby("date").size().reset_index(name="count").set_index("date")
st.line_chart(trend)
card_end()

c1, c2 = st.columns(2, gap="large")

with c1:
    card("Top districts (hotspots)", "")
    if "district" in df.columns:
        top_d = df["district"].fillna("Unknown").value_counts().head(10).reset_index()
        top_d.columns = ["district","count"]
        st.bar_chart(top_d.set_index("district"))
        st.dataframe(top_d, use_container_width=True, hide_index=True)
    else:
        st.info("No district data.")
    card_end()

with c2:
    card("Top categories", "")
    if "category" in df.columns:
        top_c = df["category"].fillna("other").value_counts().head(10).reset_index()
        top_c.columns = ["category","count"]
        st.bar_chart(top_c.set_index("category"))
        st.dataframe(top_c, use_container_width=True, hide_index=True)
    else:
        st.info("No category data.")
    card_end()

card("Status breakdown", "")
if "status" in df.columns:
    s = df["status"].fillna("New").value_counts().reset_index()
    s.columns = ["status","count"]
    st.bar_chart(s.set_index("status"))
    st.dataframe(s, use_container_width=True, hide_index=True)
else:
    st.info("No status data.")
card_end()
