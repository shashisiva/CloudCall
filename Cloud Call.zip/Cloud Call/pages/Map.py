import streamlit as st
import pandas as pd
import pydeck as pdk

from storage import load_issues
from utils import parse_ts, get_lat_lon
from constants import CATEGORIES, PROVINCE_TO_DISTRICTS
from ui import inject_css, safe_image, card, card_end

st.set_page_config(page_title="Cloud Call • Map", layout="wide")
inject_css()

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Map View")
    st.caption("Pins for reported issues")

issues = load_issues() or []

st.markdown("## 🗺️ Map View")
st.markdown('<div class="cc-sub">See all issues as pins. Filter by date, category, region.</div>', unsafe_allow_html=True)

# Filters
with st.sidebar:
    st.markdown("#### Filters")
    provinces = st.multiselect("Province", list(PROVINCE_TO_DISTRICTS.keys()), default=[])
    all_districts = sorted({d for ds in PROVINCE_TO_DISTRICTS.values() for d in ds})
    district_opts = sorted({d for p in provinces for d in PROVINCE_TO_DISTRICTS[p]}) if provinces else all_districts
    districts = st.multiselect("District", district_opts, default=[])
    cats = st.multiselect("Category", CATEGORIES, default=[])

    st.markdown("#### Date range")
    import datetime as dt
    today = dt.date.today()
    start = st.date_input("From", value=today - dt.timedelta(days=14))
    end = st.date_input("To", value=today)

filtered = []
for it in issues:
    if provinces and it.get("province") not in provinces:
        continue
    if districts and it.get("district") not in districts:
        continue
    if cats and it.get("category") not in cats:
        continue
    d = parse_ts(it).date()
    if d < start or d > end:
        continue
    filtered.append(it)

card("Interactive map", f"Pins: {len(filtered)}")
if not filtered:
    st.info("No issues to show for these filters.")
    card_end()
    st.stop()

rows = []
for it in filtered:
    lat, lon = get_lat_lon(it.get("province",""), it.get("district",""), it.get("lat"), it.get("lon"))
    rows.append({
        "id": str(it.get("id","")),
        "category": it.get("category","other"),
        "severity": it.get("severity",""),
        "status": it.get("status",""),
        "province": it.get("province",""),
        "district": it.get("district",""),
        "description": (it.get("description","") or "")[:120],
        "lat": lat,
        "lon": lon,
    })

df = pd.DataFrame(rows)

# color by category (simple)
def cat_color(c: str):
    c = (c or "other").lower()
    if c in ("flood","rain","tsunami"): return [0, 160, 255, 180]
    if c in ("cyclone","wind"): return [120, 120, 255, 180]
    if c in ("fire",): return [255, 90, 60, 180]
    if c in ("landslide",): return [160, 120, 70, 180]
    if c in ("power",): return [255, 210, 60, 180]
    return [120, 120, 120, 180]

df["color"] = df["category"].apply(cat_color)

view_state = pdk.ViewState(latitude=7.8731, longitude=80.7718, zoom=6.3)

layer = pdk.Layer(
    "ScatterplotLayer",
    data=df,
    get_position='[lon, lat]',
    get_fill_color="color",
    get_radius=22000,
    pickable=True,
    auto_highlight=True
)

tooltip = {
    "html": """
    <b>{category}</b> • {severity} • {status}<br/>
    {district}, {province}<br/>
    <span style="opacity:0.8;">ID: {id}</span><br/>
    <i>{description}</i>
    """,
    "style": {"backgroundColor": "white", "color": "black"}
}

st.pydeck_chart(pdk.Deck(layers=[layer], initial_view_state=view_state, tooltip=tooltip), use_container_width=True)
card_end()

st.markdown("### List (for quick copy/paste)")
st.dataframe(df[["id","category","severity","status","province","district","description"]], use_container_width=True, hide_index=True)
