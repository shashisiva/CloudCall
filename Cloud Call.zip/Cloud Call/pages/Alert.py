import streamlit as st
import datetime as dt

from constants import CATEGORIES, PROVINCE_TO_DISTRICTS
from storage import load_subscriptions, add_subscription, delete_subscription, load_issues
from notifier import send_email
from ui import inject_css, safe_image, card, card_end

st.set_page_config(page_title="Cloud Call • Alerts", layout="wide")
inject_css()

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Alerts & Subscriptions")
    st.caption("Email is optional (SMTP).")

st.markdown("## 🔔 Alerts & Subscriptions")
st.markdown('<div class="cc-sub">Subscribe to provinces/districts/categories. Test alerts (simulated or real SMTP email).</div>', unsafe_allow_html=True)

tabs = st.tabs(["Create subscription", "Manage subscriptions", "Send test alert"])

# ---------------- Create subscription ----------------
with tabs[0]:
    card("Create a subscription", "")
    email = st.text_input("Email to notify", value="")
    provinces = st.multiselect("Province", list(PROVINCE_TO_DISTRICTS.keys()), default=[])
    all_districts = sorted({d for ds in PROVINCE_TO_DISTRICTS.values() for d in ds})
    district_opts = sorted({d for p in provinces for d in PROVINCE_TO_DISTRICTS[p]}) if provinces else all_districts
    districts = st.multiselect("District", district_opts, default=[])
    cats = st.multiselect("Category", CATEGORIES, default=[])

    if st.button("Save subscription", type="primary"):
        if not email.strip() or "@" not in email:
            st.error("Please enter a valid email.")
        else:
            sub = {
                "id": f"SUB-{dt.datetime.now().strftime('%Y%m%d%H%M%S')}",
                "email": email.strip(),
                "provinces": provinces,
                "districts": districts,
                "categories": cats,
                "created_at": dt.datetime.now().isoformat(timespec="seconds"),
            }
            add_subscription(sub)
            st.success("Saved ✅")
            st.json(sub)

    card_end()

# ---------------- Manage subscriptions ----------------
with tabs[1]:
    subs = load_subscriptions() or []
    card("Saved subscriptions", f"Total: {len(subs)}")
    if not subs:
        st.info("No subscriptions yet.")
        card_end()
    else:
        for s in subs:
            with st.expander(f"{s.get('email')} • {s.get('id')}"):
                st.write("**Provinces:**", ", ".join(s.get("provinces") or []) or "(any)")
                st.write("**Districts:**", ", ".join(s.get("districts") or []) or "(any)")
                st.write("**Categories:**", ", ".join(s.get("categories") or []) or "(any)")
                if st.button(f"Delete {s.get('id')}", key=f"del_{s.get('id')}"):
                    delete_subscription(str(s.get("id")))
                    st.success("Deleted ✅ (refresh page)")
        card_end()

# ---------------- Send test alert ----------------
with tabs[2]:
    subs = load_subscriptions() or []
    issues = load_issues() or []

    card("Send test alert", "")
    if not subs:
        st.info("Create a subscription first.")
        card_end()
    else:
        # pick a recent issue as payload
        recent_ids = [str(x.get("id")) for x in issues[-30:] if x.get("id")] if issues else []
        selected_issue_id = st.selectbox("Pick an issue to send", options=recent_ids or ["(no issues yet)"])
        to_all = st.checkbox("Send to ALL subscribers (ignoring filters)", value=False)

        subject = st.text_input("Email subject", value="Cloud Call Alert")
        if st.button("Send"):
            if selected_issue_id == "(no issues yet)":
                st.error("No issues exist yet. Create an issue first.")
                st.stop()

            issue = next((x for x in issues if str(x.get("id")) == str(selected_issue_id)), None)
            if not issue:
                st.error("Issue not found.")
                st.stop()

            # filter subscribers
            targets = []
            for s in subs:
                if to_all:
                    targets.append(s.get("email"))
                    continue
                ok = True
                if s.get("provinces") and issue.get("province") not in s.get("provinces"):
                    ok = False
                if s.get("districts") and issue.get("district") not in s.get("districts"):
                    ok = False
                if s.get("categories") and issue.get("category") not in s.get("categories"):
                    ok = False
                if ok:
                    targets.append(s.get("email"))

            targets = [t for t in targets if t and "@" in t]
            if not targets:
                st.warning("No subscribers match this issue (based on filters).")
                st.stop()

            body = f"""Cloud Call Alert

Issue ID: {issue.get('id')}
Category: {issue.get('category')}  Severity: {issue.get('severity')}
Location: {issue.get('district')}, {issue.get('province')}
Status: {issue.get('status')}
When: {issue.get('incident_datetime')}

Description:
{issue.get('description')}
"""
            sent = send_email(targets, subject, body)
            if sent:
                st.success(f"Email sent ✅ to: {', '.join(targets)}")
            else:
                st.info("SMTP not configured → simulated send (no real email sent).")
                st.write("Would send to:", ", ".join(targets))
                st.code(body)

    card_end()
