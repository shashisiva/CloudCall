import streamlit as st
import datetime as dt

from constants import CATEGORIES, SEVERITIES, DAMAGE_TYPES, PROVINCE_TO_DISTRICTS
from storage import add_issue, save_uploaded_images, load_issues
from utils import find_possible_duplicate
from ui import inject_css, safe_image, card, card_end

# Optional moderation API (won't block if offline)
import os
import requests

st.set_page_config(page_title="Cloud Call • Report", layout="wide")
inject_css()

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Report a Disaster Issue")
    st.caption("Keep it short + clear.")

st.markdown("## 📝 Disaster Issue Reporter")
st.markdown('<div class="cc-sub">Add severity, people impacted, and images. No future dates/times allowed.</div>', unsafe_allow_html=True)

API_URL = os.getenv("MODERATION_API_URL", "http://127.0.0.1:8000/moderate")

def get_toxicity_score(text: str):
    try:
        r = requests.post(API_URL, json={"text": text}, timeout=6)
        r.raise_for_status()
        data = r.json()
        return data.get("toxicity_score"), data.get("decision")
    except Exception:
        # If moderation API is unavailable, don't block the report
        return None, "accepted"


# --- Form ---
left, right = st.columns([1, 1], gap="large")

with left:
    category = st.selectbox("Category", CATEGORIES, index=0)
    severity = st.selectbox("Severity", SEVERITIES, index=1)

    province = st.selectbox("Province", list(PROVINCE_TO_DISTRICTS.keys()))
    district = st.selectbox("District", PROVINCE_TO_DISTRICTS[province])

    damage_type = st.selectbox("Damage type", DAMAGE_TYPES, index=0)

with right:
    address = st.text_input("Nearest landmark / address (optional)", value="")
    lat = st.number_input("Latitude (optional)", value=0.0, step=0.0001, format="%.6f")
    lon = st.number_input("Longitude (optional)", value=0.0, step=0.0001, format="%.6f")
    # Treat 0,0 as not provided
    lat_val = None if abs(lat) < 1e-9 and abs(lon) < 1e-9 else float(lat)
    lon_val = None if abs(lat) < 1e-9 and abs(lon) < 1e-9 else float(lon)

desc = st.text_area("Issue description (max 300 chars)", max_chars=300, height=140)

c1, c2, c3 = st.columns([1,1,1])
with c1:
    people_impacted = st.number_input("People impacted (optional)", min_value=0, value=0, step=1)
with c2:
    injuries = st.number_input("Injuries (optional)", min_value=0, value=0, step=1)
with c3:
    reporter_name = st.text_input("Reported by (optional)", value="")

st.markdown("### Images")
uploaded_files = st.file_uploader(
    "Upload up to 3 images",
    type=["jpg","jpeg","png","webp","JPG","JPEG","PNG","WEBP"],
    accept_multiple_files=True
)
if uploaded_files:
    st.caption(f"Selected: {len(uploaded_files)} file(s)")
    for f in uploaded_files[:3]:
        st.image(f, use_container_width=True)

now = dt.datetime.now()
now_date = now.date()
now_time = now.time().replace(second=0, microsecond=0)

incident_date = st.date_input("Incident Date", value=now_date, max_value=now_date, key="incident_date")
incident_time = st.time_input("Incident Time", value=now_time, key="incident_time")

if st.session_state["incident_date"] == now_date and st.session_state["incident_time"] > now_time:
    st.warning("Time cannot be in the future for today's date. Resetting to current time.")
    st.session_state["incident_time"] = now_time

st.divider()

if st.button("Submit", type="primary"):
    desc_clean = (desc or "").strip()
    if not desc_clean:
        st.error("Please enter an issue description.")
        st.stop()

    incident_dt = dt.datetime.combine(st.session_state["incident_date"], st.session_state["incident_time"])
    if incident_dt > now:
        st.error("Incident date/time cannot be in the future.")
        st.stop()

    # Build issue record
    issue = {
        "id": dt.datetime.now().strftime("%Y%m%d%H%M%S"),
        "category": category,
        "severity": severity,
        "province": province,
        "district": district,
        "damage_type": damage_type,
        "address": address.strip(),
        "lat": lat_val,
        "lon": lon_val,
        "description": desc_clean,
        "people_impacted": int(people_impacted),
        "injuries": int(injuries),
        "reported_by": reporter_name.strip(),
        "incident_datetime": incident_dt.isoformat(timespec="minutes"),
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "status": "New",
        "assigned_to": "",
        "team": "",
        "eta": "",
        "notes": "",
        "history": [
            {"ts": dt.datetime.now().isoformat(timespec="seconds"), "action": "created", "by": reporter_name.strip() or "anonymous"}
        ],
    }

    # Duplicate detection
    existing = load_issues() or []
    dup = find_possible_duplicate(issue, existing)
    if dup:
        st.warning(f"Possible duplicate found (ID {dup.get('id')}) — still saving, but please verify in Dashboard.")

    # Moderation
    score, decision = get_toxicity_score(desc_clean)
    issue["toxicity_score"] = score
    issue["toxicity_decision"] = decision

    if decision == "rejected":
        st.error(f"Description rejected by moderation. Toxicity score: {score}")
        st.stop()

    # Save images
    images = save_uploaded_images((uploaded_files or [])[:3])
    issue["images"] = images
    # Backwards-compat single field (for older dashboards)
    issue["image_path"] = images[0] if images else None

    add_issue(issue)
    st.success("Saved ✅")

    card("Saved issue", f"ID: {issue['id']}")
    st.json(issue)
    card_end()
