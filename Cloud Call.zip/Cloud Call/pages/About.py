import streamlit as st
from ui import inject_css, safe_image, card, card_end

st.set_page_config(page_title="Cloud Call • About", layout="wide")
inject_css()

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Cloud Call")
    st.caption("Community hazard reporting")

st.markdown("## ☁️ Cloud Call")
st.markdown('<div class="cc-sub">A simple disaster reporting + alerting demo app</div>', unsafe_allow_html=True)

card("What you can do", "")
st.markdown(
"""
- Report an issue with **category, severity, time, location, images**
- See issues on **Dashboard** (filters + search + status workflow + export)
- Browse a **Map View** (pins, heat-like view)
- See **Analytics** (hotspots + trends)
- Manage **Alerts & Subscriptions** (simulated or SMTP email)
- **Admin/Moderation** page to review, assign, resolve, reject
"""
)
card_end()

card("Running the app", "")
st.code(
"""# 1) Install
pip install -r requirements.txt

# 2) Run
streamlit run sampleApp.py
""",
language="bash"
)
st.caption("Tip: If you want real emails, set SMTP_HOST/SMTP_USER/SMTP_PASS/FROM_EMAIL as environment variables.")
card_end()
