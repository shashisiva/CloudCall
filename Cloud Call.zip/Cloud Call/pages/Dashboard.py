import streamlit as st
import pandas as pd
import datetime as dt
import pydeck as pdk
from pathlib import Path

from constants import CATEGORIES, SEVERITIES, STATUSES, PROVINCE_TO_DISTRICTS
from storage import load_issues, update_issue
from utils import parse_ts, time_ago, get_lat_lon
from ui import inject_css, safe_image, card, card_end

st.set_page_config(page_title="Cloud Call • Dashboard", layout="wide", initial_sidebar_state="expanded")
inject_css()

CATEGORY_ICONS = {
    "flood": "🌊",
    "rain": "🌧️",
    "cyclone": "🌀",
    "tsunami": "🌊",
    "wind": "💨",
    "fire": "🔥",
    "landslide": "🪨",
    "power": "⚡",
    "other": "📌",
}

def icon_for(cat: str) -> str:
    return CATEGORY_ICONS.get((cat or "other").lower(), "📌")

with st.sidebar:
    safe_image("assets/cloud.jpg", use_container_width=True)
    st.markdown("### Cloud Call")
    st.caption("Dashboard • filters • workflow")

    st.divider()
    st.caption("Tip: Filter by district + status to work the queue.")

st.markdown("## 📊 Dashboard")
st.markdown('<div class="cc-sub">Search, filter, update status, assign work, export CSV</div>', unsafe_allow_html=True)

issues = load_issues() or []

# ---------------- Sidebar filters ----------------
with st.sidebar:
    st.markdown("#### Filters")
    q = st.text_input("Search (description / ID)", value="")

    provinces = st.multiselect("Province", list(PROVINCE_TO_DISTRICTS.keys()), default=[])

    all_districts = sorted({d for ds in PROVINCE_TO_DISTRICTS.values() for d in ds})
    if provinces:
        district_opts = sorted({d for p in provinces for d in PROVINCE_TO_DISTRICTS[p]})
    else:
        district_opts = all_districts
    districts = st.multiselect("District", district_opts, default=[])

    cats = st.multiselect("Category", CATEGORIES, default=[])
    severities = st.multiselect("Severity", SEVERITIES, default=[])
    statuses = st.multiselect("Status", STATUSES, default=[])

    st.markdown("#### Date range")
    # Default range: last 14 days
    today = dt.date.today()
    start = st.date_input("From", value=today - dt.timedelta(days=14))
    end = st.date_input("To", value=today)

    sort_by = st.selectbox("Sort by", ["Newest", "Oldest", "Severity (high→low)"], index=0)

# ---------------- Apply filters ----------------
def severity_rank(s: str) -> int:
    order = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
    return order.get(s or "", 0)

filtered = []
for it in issues:
    sid = str(it.get("id", ""))
    desc = (it.get("description") or "")
    if q.strip():
        if q.lower() not in sid.lower() and q.lower() not in desc.lower():
            continue

    if provinces and it.get("province") not in provinces:
        continue
    if districts and it.get("district") not in districts:
        continue
    if cats and it.get("category") not in cats:
        continue
    if severities and it.get("severity") not in severities:
        continue
    if statuses and it.get("status") not in statuses:
        continue

    ts = parse_ts(it).date()
    if ts < start or ts > end:
        continue

    filtered.append(it)

if sort_by == "Newest":
    filtered.sort(key=parse_ts, reverse=True)
elif sort_by == "Oldest":
    filtered.sort(key=parse_ts, reverse=False)
else:
    filtered.sort(key=lambda x: (severity_rank(x.get("severity")), parse_ts(x)), reverse=True)

# ---------------- KPIs ----------------
k1, k2, k3, k4 = st.columns(4)
k1.metric("Total (filtered)", len(filtered))
k2.metric("New", sum(1 for x in filtered if x.get("status") == "New"))
k3.metric("Assigned", sum(1 for x in filtered if x.get("status") == "Assigned"))
k4.metric("Resolved", sum(1 for x in filtered if x.get("status") == "Resolved"))

st.markdown("")

# ---------------- Table + Export ----------------
card("Issue list", "Click an ID below to open details")
if not filtered:
    st.info("No issues match your filters.")
    card_end()
else:
    df = pd.DataFrame(filtered)

    # normalize columns
    for c in ["severity","status","assigned_to","team","eta","reported_by","province","district","category"]:
        if c not in df.columns:
            df[c] = ""

    df["created_ts"] = df.apply(lambda r: parse_ts(r).isoformat(sep=" ", timespec="seconds") if isinstance(r, dict) else "", axis=1) if False else ""
    # safer: build explicit created_at sort key
    df["_ts"] = df.apply(lambda row: parse_ts(row.to_dict()), axis=1)

    show_cols = [c for c in ["id","category","severity","status","province","district","incident_datetime","created_at","assigned_to","team","eta"] if c in df.columns]
    df_show = df[show_cols].copy()
    df_show = df_show.sort_values(by="created_at", ascending=False, na_position="last") if "created_at" in df_show.columns else df_show

    st.dataframe(df_show, use_container_width=True, hide_index=True)

    csv = df_show.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download CSV", data=csv, file_name="cloudcall_issues.csv", mime="text/csv")

    card_end()

# ---------------- Details view ----------------
st.markdown("### 🔎 Issue details")
ids = [str(x.get("id")) for x in filtered if x.get("id")]
if not ids:
    st.info("No issues to show.")
    st.stop()

selected_id = st.selectbox("Select Issue ID", ids)
selected = next((x for x in issues if str(x.get("id")) == str(selected_id)), None)

if not selected:
    st.info("Issue not found.")
    st.stop()

# Show details + workflow controls
left, right = st.columns([1.15, 0.85], gap="large")

with left:
    cat = selected.get("category","other")
    st.markdown(f"#### {icon_for(cat)} {cat} • **{selected.get('severity','')}**")
    st.caption(f"{selected.get('province','')} • {selected.get('district','')} • {time_ago(parse_ts(selected))}")

    st.write("**Description:**")
    st.write(selected.get("description",""))

    st.write("**Damage type:**", selected.get("damage_type",""))
    st.write("**People impacted:**", selected.get("people_impacted", 0))
    st.write("**Injuries:**", selected.get("injuries", 0))
    if selected.get("address"):
        st.write("**Address:**", selected.get("address"))

    # Images
    images = selected.get("images") or []
    if images:
        st.markdown("**Images:**")
        st.image([p for p in images if p and Path(p).exists()], use_container_width=True)
    elif selected.get("image_path") and Path(selected.get("image_path")).exists():
        st.image(selected.get("image_path"), use_container_width=True)

with right:
    card("Workflow", f"ID: {selected.get('id')}")
    new_status = st.selectbox("Status", STATUSES, index=max(0, STATUSES.index(selected.get("status","New")) if selected.get("status") in STATUSES else 0))
    assigned_to = st.text_input("Assigned to", value=selected.get("assigned_to",""))
    team = st.text_input("Team", value=selected.get("team",""))
    eta = st.text_input("ETA", value=selected.get("eta",""))
    notes = st.text_area("Notes", value=selected.get("notes",""), height=120)

    if st.button("Save changes", type="primary"):
        patch = {
            "status": new_status,
            "assigned_to": assigned_to.strip(),
            "team": team.strip(),
            "eta": eta.strip(),
            "notes": notes.strip(),
        }
        # append history
        hist = selected.get("history") or []
        hist.append({
            "ts": dt.datetime.now().isoformat(timespec="seconds"),
            "action": "updated",
            "by": assigned_to.strip() or "admin",
            "note": f"Status={new_status}, Team={team.strip()}, ETA={eta.strip()}",
        })
        patch["history"] = hist

        ok = update_issue(str(selected.get("id")), patch)
        if ok:
            st.success("Updated ✅ (refresh page if needed)")
        else:
            st.error("Update failed.")

    card_end()

st.markdown("---")

# ---------------- Mini map for this issue ----------------
lat, lon = get_lat_lon(selected.get("province",""), selected.get("district",""), selected.get("lat"), selected.get("lon"))
mini_df = pd.DataFrame([{"lat": lat, "lon": lon, "label": f"{selected.get('district','')}"}])

view_state = pdk.ViewState(latitude=lat, longitude=lon, zoom=10)
layer = pdk.Layer(
    "ScatterplotLayer",
    data=mini_df,
    get_position='[lon, lat]',
    get_radius=250,
    pickable=True,
)
st.pydeck_chart(pdk.Deck(layers=[layer], initial_view_state=view_state), use_container_width=True)
